from .forms import GenericAlertForm
from django.shortcuts import render
from django.http import HttpResponse
from .models import GenericAlertPlugin
from django.contrib.auth.models import User


def PluginView(request):
    user = request.user
    # return HttpResponse(user.pk)
    try:
        generic_obj = GenericAlertPlugin.objects.get(alert_receiver=user.pk)
    except Exception:
        generic_obj = None

    form = GenericAlertForm(request.POST or None, instance=generic_obj)

    if request.method == "POST" and form.is_valid():
        user_id = form.cleaned_data.get("user_id")
        GenericAlertPlugin.objects.create(
            user_id=user_id, alert_receiver=request.user
        )
        

    context = {
        "form": form,
        "plugin_name": GenericAlertPlugin.__name__
    }
    return render(request, "plugins/plugin.html", context)
