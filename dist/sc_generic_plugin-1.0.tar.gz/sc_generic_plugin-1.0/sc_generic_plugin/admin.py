from django.contrib import admin
from .models import AlertPlugin, GenericAlertPlugin

admin.site.register(GenericAlertPlugin)

