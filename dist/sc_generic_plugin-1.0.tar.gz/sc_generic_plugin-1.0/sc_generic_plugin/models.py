from checkerapp.models import AlertPlugin, BaseCheck
from django.db import models
from polymorphic.models import PolymorphicModel
from celery import shared_task

class GenericAlertPlugin(AlertPlugin):

    # NORMAL, WARNING, CRITICAL = list(range(3))
    # SEVERE_CHOICES = ((NORMAL, "NORMAL"), (WARNING, "WARNING"), (CRITICAL, "CRITICAL"))
    
    '''
    0 -> Normal
    1 -> Warning
    2 -> Critical

    Refer following thread -> www.github.com/xxxxxxx
    '''
    severe_level = 1
    url = 'accounts:generic_plugin:generic_pluginview'
    user_id = models.CharField(max_length=50)
    # active_status = models.BooleanField(default=True)

    @shared_task
    def send_alert_task(task_obj):
        return 'Generic task'