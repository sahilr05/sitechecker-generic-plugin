from setuptools import setup, find_packages

setup(
    name="sc_generic_plugin",
    version="1.0",
    description="sitechecker generic plugin",
    author="Sahil Rajpal",
    author_email="sahilrajpal85@gmail.com",
    packages=find_packages(),
)
